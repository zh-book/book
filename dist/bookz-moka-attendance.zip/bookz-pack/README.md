# bookz

本目录为 Moka 考勤工时 Chrome 插件工程。

## 放到本机

目标路径：`/Users/bookz/Desktop/bookz`

```bash
mkdir -p /Users/bookz/Desktop/bookz
cd /Users/bookz/Desktop/bookz
# 方式 1：从仓库拉取本分支
git clone -b cursor/moka-attendance-hours-extension-0d0d https://github.com/zh-book/book.git .
# 方式 2：解压 zip 后，把 moka-attendance-extension 拷进本目录
```

加载扩展时选择：`/Users/bookz/Desktop/bookz/moka-attendance-extension`
